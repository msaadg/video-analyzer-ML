import { VideoPage } from './pages/VideoPage'

function App() {

  return (
    <div className="min-h-screen bg-gray-100">
      <VideoPage />
    </div>
  );
}

export default App
